package com.airline.flightlist;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.airline.booking.BookingDTO;

@Controller
public class FlightlistController {
	
	@RequestMapping(method = RequestMethod.POST, value="/flight_list")
	public ModelAndView newbook() {
		String url = "http://openapi.airport.co.kr/service/rest/FlightStatusList/getFlightStatusList?ServiceKey=\r\n"
				+ "QLY6sbjKireWvs8pV87xMUGDGn%2FNt0%2BRcukxGVpSRTcBhSkQvf7Q79j%2FpOOIie%2FZ3YydD3VqFH1gzx9v7l0IuQ%3D%3D\r\n"
				+ "&schStTime=0600&schEdTime=1800&schLineType=I&schIOType=I&schAirCode=PUS&pageNo=1";
		int des_flag = 0; // description 태그 구분을 위한 flag
		ModelAndView mv = documentBuilder(url, des_flag);
		
		mv.setViewName("search");
		
		return mv;
	}

	private ModelAndView documentBuilder(String url, int des_flag) {
		// TODO Auto-generated method stub
		return null;
	}
	@RequestMapping(method = RequestMethod.POST, value="/flight_listresult")
	public ModelAndView search_result(HttpServletRequest request) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String search_type = request.getParameter("search_type");
		String search_value_encode = request.getParameter("search_value");
		String search_value = null;
		StringBuilder urlBuilder = new StringBuilder("http://openapi.airport.co.kr/service/rest/FlightStatusList/getFlightStatusList?ServiceKey=\r\n"
				+ "QLY6sbjKireWvs8pV87xMUGDGn%2FNt0%2BRcukxGVpSRTcBhSkQvf7Q79j%2FpOOIie%2FZ3YydD3VqFH1gzx9v7l0IuQ%3D%3D\r\n"
				+ "&schStTime=0600&schEdTime=1800&schLineType=I&schIOType=I&schAirCode=PUS&pageNo=1");
		urlBuilder.append(search_type);
		urlBuilder.append("&QueryType=");
		urlBuilder.append(search_type);
		String url = urlBuilder.toString();
		
		int des_flag = 1; // description 태그 구분을 위한 flag
		ModelAndView mv =  documentBuilder(url, des_flag);
		mv.addObject("search_type", search_value_encode);
		mv.setViewName("flight_listresult");
		return mv;
	}
	private static ModelAndView documentBuilder1(String url, int des_flag) {
		ModelAndView mv = new ModelAndView();
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = null;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			org.w3c.dom.Document doc = dBuilder.parse(url);
			doc.getDocumentElement().normalize();
			org.w3c.dom.NodeList nList = doc.getElementsByTagName("item");
			
			String[] air_code = new String[nList.getLength()];
			String[] air_kor = new String[nList.getLength()];
			String[] arrive_kor = new String[nList.getLength()];
			String[] bording_kor = new String[nList.getLength()];
			String[] flight_date = new String[nList.getLength()];
			String[] arrive_time = new String[nList.getLength()];
			String[] bording_time = new String[nList.getLength()];
			
			ArrayList<BookingDTO> alist = new ArrayList<BookingDTO>();
			for(int temp=0; temp<nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if(nNode.getNodeType() == Node.ELEMENT_NODE) {
					org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
					String air_codeTag = getTagValue("air_code", eElement);
					String air_korTag = getTagValue("air_kor", eElement);
					String arrive_korTag = getTagValue("arrive_kor", eElement);
					String bording_korTag = getTagValue("bording_kor", eElement);
					String flight_dateTag = getTagValue("flight_date", eElement);
					String arrive_timeTag = getTagValue("arrive_time", eElement);
					String bording_timeTag = getTagValue("bording_time", eElement);
					
					air_code[temp] = air_codeTag;
					air_kor[temp] = air_korTag;
					arrive_kor[temp] = arrive_korTag;
					bording_kor[temp] = bording_korTag;
					flight_date[temp] = flight_dateTag;
					arrive_time[temp] = arrive_timeTag;
					bording_time[temp] = bording_timeTag;
					
					if(des_flag == 0) { // 항공 목록
						air_code[temp] = air_codeTag;
					}
					else if(des_flag == 1) { // 검색 결과 목록
						int idx = air_codeTag.indexOf("<br/>");
						air_code[temp] = air_codeTag.substring(idx+5);
					}
					
					alist.add(new BookingDTO(temp, air_codeTag, temp, temp, air_korTag, arrive_korTag, bording_korTag, flight_dateTag, arrive_timeTag, bording_timeTag));
					
				}
			}
			
			mv.addObject("air_code", air_code);
			mv.addObject("air_kor", air_kor);
			mv.addObject("arrive_kor", arrive_kor);
			mv.addObject("bording_kor", bording_kor);
			mv.addObject("flight_date", flight_date);
			mv.addObject("arrive_time", arrive_time);
			mv.addObject("bording_time", bording_time);
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}
	
	private static String getTagValue(String tag, org.w3c.dom.Element eElement) {
		org.w3c.dom.NodeList nList = eElement.getElementsByTagName(tag).item(0).getChildNodes();
		
		Node nValue = (Node) nList.item(0);
		if(nValue == null) {
			return null;
		}
		return nValue.getNodeValue();
	}
}
