package com.airline.join;

public interface JoinService {
	public void join_member(String mem_id, String mem_pw, String mem_name, String mem_birth, String mem_tel, String mem_email, String mem_address);
}
