package com.airline.booking;

import java.util.ArrayList;

public interface BookingService {
		
		// 항공예약
		public void booking_insert(int book_no, int mem_no, String mem_id, String air_code, String air_kor,
					String arrive_kor, String bording_kor, String flight_date, String arrive_time, String bording_time,
					String people, String book_status);
		
		// 예약확인
		public ArrayList<BookingDTO> book_check(int book_no);

		public void bebook_update(int book_no);

		public static int book_full(int mem_no) {
			// TODO Auto-generated method stub
			return 0;
		}


}
