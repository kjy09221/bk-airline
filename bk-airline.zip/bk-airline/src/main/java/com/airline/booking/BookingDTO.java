package com.airline.booking;

public class BookingDTO {
	int book_no; //예약번호
	String air_code; //항공사 코드
	int mem_no, mem_id; //멤버 번호, 멤버 아이디
	String air_kor, arrive_kor, bording_kor, flight_date, arrive_time, bording_time, people; //항공사명, 출발지명, 도착지명, 일정, 출발시간, 도착시간, 인원 수
	public BookingDTO() {}
	public BookingDTO(int book_no, String air_code, int mem_no, int mem_id, String air_kor, String arrive_kor,
			String bording_kor, String flight_date, String arrive_time, String bording_time) {
		super();
		this.book_no = book_no;
		this.air_code = air_code;
		this.mem_no = mem_no;
		this.mem_id = mem_id;
		this.air_kor = air_kor;
		this.arrive_kor = arrive_kor;
		this.bording_kor = bording_kor;
		this.flight_date = flight_date;
		this.arrive_time = arrive_time;
		this.bording_time = bording_time;
		this.people = people;
	}
	public int getBook_no() {
		return book_no;
	}
	public void setBook_no(int book_no) {
		this.book_no = book_no;
	}
	public String getAir_code() {
		return air_code;
	}
	public void setAir_code(String air_code) {
		this.air_code = air_code;
	}
	public int getMem_no() {
		return mem_no;
	}
	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}
	public int getMem_id() {
		return mem_id;
	}
	public void setMem_id(int mem_id) {
		this.mem_id = mem_id;
	}
	public String getAir_kor() {
		return air_kor;
	}
	public void setAir_kor(String air_kor) {
		this.air_kor = air_kor;
	}
	public String getArrive_kor() {
		return arrive_kor;
	}
	public void setArrive_kor(String arrive_kor) {
		this.arrive_kor = arrive_kor;
	}
	public String getBording_kor() {
		return bording_kor;
	}
	public void setBording_kor(String bording_kor) {
		this.bording_kor = bording_kor;
	}
	public String getFlight_date() {
		return flight_date;
	}
	public void setFlight_date(String flight_date) {
		this.flight_date = flight_date;
	}
	public String getArrive_time() {
		return arrive_time;
	}
	public void setArrive_time(String arrive_time) {
		this.arrive_time = arrive_time;
	}
	public String getBording_time() {
		return bording_time;
	}
	public void setBording_time(String bording_time) {
		this.bording_time = bording_time;
	}
	public String getPeople() {
		return people;
	}
	public void setPeople(String people) {
		this.people = people;
	}
}