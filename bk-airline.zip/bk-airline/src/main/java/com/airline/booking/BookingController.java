package com.airline.booking;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.airline.booking.BookingDTO;
import com.airline.booking.BookingService;

@Controller
public class BookingController {
	
	@Autowired
	private SqlSession sqlsession;

	// 예약 확인 페이지
	@RequestMapping(value="/booking_confirm", produces = "application/text; charset=utf8")
	public ModelAndView test(HttpServletRequest request) {
		int book_no=Integer.parseInt(request.getParameter("book_no"));
		int mem_no=Integer.parseInt(request.getParameter("mem_no"));
		int mem_id=Integer.parseInt(request.getParameter("mem_id"));
		String air_code = request.getParameter("air_code");
		String air_kor = request.getParameter("air_kor");
		String arrive_kor = request.getParameter("arrive_kor");
		String bording_kor = request.getParameter("bording_kor");
		String flight_date = request.getParameter("flight_date");
		String arrive_time = request.getParameter("arrive_time");
		String bording_time =request.getParameter("bording_time");
		String people = request.getParameter("people");
		
		BookingService bebookService = sqlsession.getMapper(BookingService.class);
		// 예약 상태 확인 book_status이 true면 대출 가능 
		ArrayList<BookingDTO> book_status_list = bebookService.book_check(book_no);
		Boolean book_status = book_status_list.isEmpty();
		
		// 회원의 예약 건수 
		int bnum = BookingService.book_full(mem_no);
		
		ModelAndView mv = new ModelAndView();
		
		mv.addObject("bnum", bnum); //예약건수
		mv.addObject("book_no", book_no); //예약번호
		mv.addObject("mem_no", mem_no); //멤버번호
		mv.addObject("mem_id", mem_id); //멤버아이디
		mv.addObject("air_code", air_code); //항공사코드
		mv.addObject("air_kor", air_kor); //항공사명
		mv.addObject("arrive_kor", arrive_kor); //출발지명
		mv.addObject("bording_kor", bording_kor); //도착지명
		mv.addObject("flight_date", flight_date); //비행날짜
		mv.addObject("arrive_time", arrive_time); //출발시간
		mv.addObject("bording_time", bording_time); //도착시간
		mv.addObject("people", people); //인원 수
		mv.addObject("book_status", book_status); //예약 상태
		mv.setViewName("booking_confirm");
		
		return mv;
	}
	// 예약하기
		@RequestMapping(method=RequestMethod.POST, value="/booking_check")
		public String bebook(HttpServletRequest request) {
			int book_no = Integer.parseInt(request.getParameter("book_no"));
			int mem_no = Integer.parseInt(request.getParameter("mem_no"));
			String mem_id = request.getParameter("mem_id");
			String air_code = request.getParameter("air_code");
			String air_kor = request.getParameter("air_kor");
			String arrive_kor = request.getParameter("arrive_kor");
			String bording_kor = request.getParameter("bording_kor");
			String flight_date = request.getParameter("flight_date");
			String arrive_time = request.getParameter("arrive_time");
			String bording_time = request.getParameter("bording_time");
			String people = request.getParameter("people");
			String book_status = request.getParameter("book_status");

			BookingService bebookService = sqlsession.getMapper(BookingService.class);
			bebookService.booking_insert(book_no, mem_no, mem_id, air_code, air_kor, arrive_kor, bording_kor, flight_date, arrive_time, bording_time, people,book_status);
			bebookService.bebook_update(book_no);
			return "redirect:booking_list";
		}	
}