package com.ezen.booking;

public interface BookingService {

}
